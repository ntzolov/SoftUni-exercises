import { deleteItemById } from '../data/items.js';

export async function deleteView(ctx) {
  const itemId = ctx.params.id;
  await deleteItemById(itemId);
  ctx.page.redirect('/');
}
