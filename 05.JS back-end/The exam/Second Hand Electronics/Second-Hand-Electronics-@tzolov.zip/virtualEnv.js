exports.SECRET = '6d3319acf5e780d99f451ddadf768263e50b6690';
exports.PORT = 3000;
exports.DATABASE_NAME = 'second-hand-electronics';
