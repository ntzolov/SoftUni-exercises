const section = document.getElementById('home-view');

export function homeView(ctx) {
  ctx.showSection(section);
}
