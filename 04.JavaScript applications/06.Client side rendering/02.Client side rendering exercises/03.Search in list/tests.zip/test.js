const text = 'this is good';
const pattern = /goo/g;

if (text.includes('goo')) {
  console.log('yes');
} else {
  console.log('no');
}
